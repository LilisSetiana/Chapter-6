package com.example.tugas1chapter6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tugasHandler()
    }

    fun tugasHandler(){
        val handler = object : Handler(Looper.getMainLooper()){
            override fun handleMessage(msg: Message) {
                super.handleMessage(msg)
                val keterangan = msg.obj as String
                tv_hasilBMI.text = keterangan
            }
        }

        Thread(Runnable {
            btn_hitung.setOnClickListener {
                val beratBadan = et_bb.text.toString().toDouble()
                val tinggiBadan = et_tb.text.toString().toDouble() / 100
                val hasilBmi = beratBadan / (tinggiBadan * tinggiBadan)
                val kategori = if(hasilBmi < 18.5){
                    "kurus"
                }else if(hasilBmi >= 18.5 && hasilBmi < 24.9){
                    "Normal"
                }else if(hasilBmi >= 24.9 && hasilBmi < 29.9){
                    "Overweight"
                }else{
                    "Obesitas"
                }

                val message = Message.obtain()
                message.obj = kategori
                message.target = handler
                message.sendToTarget()
            }
        }).start()
    }
}