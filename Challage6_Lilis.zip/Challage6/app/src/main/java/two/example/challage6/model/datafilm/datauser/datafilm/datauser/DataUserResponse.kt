package two.example.challage6.model.datafilm.datauser.datafilm.datauser


import com.google.gson.annotations.SerializedName

class DataUserResponse : ArrayList<DataUserResponseItem>()