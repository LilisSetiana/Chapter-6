package two.example.challage6.model.datafilm.datauser.datafilm

import com.google.gson.annotations.SerializedName

class DataFilmResponse : ArrayList<DataFilmResponseItem>() 