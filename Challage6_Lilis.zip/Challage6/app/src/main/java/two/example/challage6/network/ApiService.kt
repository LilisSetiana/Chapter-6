package two.example.challage6.network

import retrofit2.Call
import retrofit2.http.*
import two.example.challage6.model.datafilm.datauser.datafilm.DataFilmResponseItem
import two.example.challage6.model.datafilm.datauser.datafilm.datauser.DataUserResponseItem

interface ApiService {

    // get data film
    @GET("film")
    fun getAllFilm() : Call<List<DataFilmResponseItem>>

    // post data register
    @POST("user")
    fun postDataUser (
        @Body request : PostRequest
    ) : Call<DataUserResponseItem>

    // get login
    @GET("user")
    fun getDataUser() : Call<List<DataUserResponseItem>>

    // update user
    @PUT("user/{id}")
    fun updateDataUser(
        @Path ("id") id : String,
        @Body requestUpdate : PutRequest) : Call<List<DataUserResponseItem>>

}
}