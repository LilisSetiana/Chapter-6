package two.example.a27april

import android.app.ProgressDialog
import android.content.Context
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

@Suppress ("DEPRECATION")
class MainActivity : AppCompatActivity() {
    lateinit var cont: Context
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cont = this
        contohAsyTaks().execute()

        btnHitung.setOnClickListener {
            contohAsyTaks().execute()
        }
//
//        val a = 7+8
//        tvHasil.text = a.toString()
    }

    inner class contohAsyTaks : AsyncTask<Int, Void, String>() {

        lateinit var pdialog: ProgressDialog

        override fun onPreExecute() {
            super.onPreExecute()
            pdialog = ProgressDialog(cont)
            pdialog.show()
        }
        override fun doInBackground(vararg p0: Int?): String {
           val berat = etBB.text.toString().toDouble()
            val tinggi = etTinggi.text.toString().toDouble()
            val int = berat / (tinggi*tinggi)
            var output = ""
            if (int < 18.4){
                output = "Berat Badan Kurang"
            }else if (int <=18.5 && int <= 24.5){
                output= "Berat Badan Ideal"
            }

            return output
        }

        override fun onProgressUpdate(vararg values: Void?) {
            super.onProgressUpdate(*values)
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            tvhasil.text = result
            pdialog.dismiss()
            etBB.setText("")
            etTinggi.setText("")
        }
    }
}